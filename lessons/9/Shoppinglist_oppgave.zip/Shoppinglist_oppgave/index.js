var shoppingList = [];

var continueAskingUserForItems = true;

while(continueAskingUserForItems) {
	var inputFromUser = prompt("Enten skriv et varenavn, eller 'avbryt' for å avbryte");
	
	if (inputFromUser === "avbryt") {
		continueAskingUserForItems = false;
		alert("Du avbrøyt programmet. Her er varene dine: " + shoppingList);
	} else if (shoppingList.includes(inputFromUser)) {
		alert("Varen " + inputFromUser + " finnes allerede i handlelisten din!");
	} else {
		shoppingList.push(inputFromUser);
		alert(inputFromUser + " har blitt lagt til i handlelisten");
	}
}