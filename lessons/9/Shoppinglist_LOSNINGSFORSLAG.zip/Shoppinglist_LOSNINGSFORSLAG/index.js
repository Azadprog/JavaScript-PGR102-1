var shoppingList = [];

var continueAskingUserForItems = true;

while(continueAskingUserForItems) {
	var inputFromUser = prompt("Enten skriv et varenavn, eller 'avbryt' for å avbryte");
	
	if (inputFromUser === "avbryt") {
		continueAskingUserForItems = false;
		alert("Du avbrøyt programmet. Her er varene dine: " + shoppingList);
		
	} else if (shoppingList.includes(inputFromUser)) {
		// Hvis koden går inn i denne betingelsen, så vet vi at varen som bruker skrev inn allerede finnes i handlelisten.
		alert("Varen " + inputFromUser + " finnes allerede i handlelisten din!");
		
		// Kodelinjen under finner hvilken index varen befinner seg på i arrayet.
		var indexOfElement = shoppingList.indexOf(inputFromUser);
		
		// Så kan vi bruke splice() til å fjerne elementet fra indexen vi fant over.
		shoppingList.splice(indexOfElement, 1);
		
		// Til slutt kan vi fortelle brukeren at varen er slettet.
		alert("Varen " + inputFromUser + " har blitt slettet!");
		
	} else {
		shoppingList.push(inputFromUser);
		alert(inputFromUser + " har blitt lagt til i handlelisten");
	}
}