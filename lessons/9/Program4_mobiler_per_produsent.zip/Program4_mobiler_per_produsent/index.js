function devicesByBrand (brand) {
  switch (brand) {
    case "Apple":
      return ["iPhone 6", "iPhone 7", "iPhone XS"];
    case "Huawei":
      return ["Mate 8", "Mate 10 Pro", "P20 Pro"];
    case "Samsung":
      return ["Note 9", "S8", "S8 Pluss"];
    default:
      return [];
  }
}

console.log(devicesByBrand("Huawei"));

console.log(devicesByBrand ("Samsung")[1]); // Note 9