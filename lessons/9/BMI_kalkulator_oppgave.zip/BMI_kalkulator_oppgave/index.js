/* Kode fra forelesning */
function bmiCalculator(weight, height) {
	return weight / (height * height);
}

var weightInputFromUser = prompt("Hva veier du? (kg)");
var heightInputFromUser = prompt("Hvor høy er du? (meter, IKKE centimeter)");

var weightNumeric = parseFloat(weightInputFromUser);
var heightNumeric = parseFloat(heightInputFromUser);

var result = bmiCalculator(weightNumeric, heightNumeric);

alert(result);