function bmiCalculator(weight, height) {
	// Løsningsforslag for "ekstraoppgaven" i oppgave 1. For å tillate centimeter trenger vi bare å dele høyden på 100 for å få verdien i "meter"-form.
	// weight / ((height/100) * (height/100));
	
	return weight / (height * height);
}

var weightInputFromUser = prompt("Hva veier du? (kg)");
var heightInputFromUser = prompt("Hvor høy er du? (meter, IKKE centimeter)");

var weightNumeric = parseFloat(weightInputFromUser);
var heightNumeric = parseFloat(heightInputFromUser);

var result = bmiCalculator(weightNumeric, heightNumeric);

/* LØSNINGSFORSLAG OPPGAVE 1 */

// Først sjekker vi om brukeren har en BMI på under eller lik 18.5
if (result <= 18.5) {
	alert("Din BMI er " + result + ", noe som tilsvarer Undervekt");
	
  // Så sjekker vi om BMI-en er mellom 18.5 og 24.9 (eller lik de to verdiene)
} else if (result >= 18.5 && result <= 24.9) {
	alert("Din BMI er " + result + ", noe som tilsvarer Normalvekt");
	
  // Så sjekker vi om BMI-en er mellom 25.0 og 29.9 (eller lik de to verdiene)
} else if (result >= 25.0 && result <= 29.9) {
	alert("Din BMI er " + result + ", noe som tilsvarer Overvekt");
	
  // Et hvilket som helst annet resultat vil i teorien tilsvare Helseskadelig overvekt/fedme, da vi har betingelser som kontrollerer for alt fra under 18.5 og opp til 29.9.
} else {
	alert("Din BMI er " + result + ", noe som tilsvarer Helseskadelig overvekt/fedme");
}