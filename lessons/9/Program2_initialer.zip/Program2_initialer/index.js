function getInitials(name) {
  var nameAsArray = name.split(" ");
  var initials = "";
  for (var i = 0; i < nameAsArray.length; i++) {
    initials += nameAsArray[i].charAt(0);
  }
  return initials;
}

console.log(getInitials("Kong Harald"));