/*
Her er datasettet vi skal bruke i dagens forelesning. Linkene er til bilder.
  "Hardangervidda" = "https://goo.gl/xgHqFa"
  "Jotunheimen" = "https://goo.gl/LzPNGb"
  "Rondane" = "https://goo.gl/F6LByy"
*/