// Lager en referanse/kobling til DOM-elementet ved ID "imageHolder" i HTML-fila.
var imageHolder = document.getElementById("imageHolder");

// Funksjonen hjelper oss med å hente ut URL til bilde av det stedet bruker skriver inn. Denne kan du fritt utvide til å inneholde så mange steder du vil!
function getImageOfPlace(place) {
	switch (place) {
		case "Hardangervidda":
			return "https://goo.gl/xgHqFa";
		case "Jotunheimen":
			return "https://goo.gl/LzPNGb";
		case "Rondane":
			return "https://goo.gl/F6LByy";
		default:
			return "";
	}
}

// Dynamisk (bruker-basert) argument til funksjonen.
var inputFromUser = prompt("Skriv inn stedsnavn: ");
imageHolder.src = getImageOfPlace(inputFromUser);

// Hardkodet argument til funksjonen.
//imageHolder.src = getImageOfPlace("Hardangervidda");