// Først lager vi en referanse til DOM-elementet <input id="inputUsername" />
var inputUsernameElement = document.getElementById("inputUsername");

// Så lager vi en referanse til DOM-elementet <input id="inputPassword" />
var inputPasswordElement = document.getElementById("inputPassword");

// Så lager vi en referanse til DOM-elementet <button id="btnLogin" />
var btnLoginElement = document.getElementById("btnLogin");

// Så lager vi en referanse til DOM-elementet <p id="status">
var pStatus = document.getElementById("pStatus");

// Så setter vi en event-lytter på knappen -- med andre ord ønsker vi å lytte på om brukeren trykker på login-knappen referert til på linje 5.
btnLoginElement.addEventListener('click', function() {
	
	// Vi sjekker verdiene bruker skrev inn i begge <input>-feltene opp mot to hardkodede verdier: brukernavn og passord.
	if (inputUsernameElement.value === "Andreas" && inputPasswordElement.value === "test") {
		// Hvis brukernavn OG passord stemmer overens, ønsk bruker velkommen.
		pStatus.innerText = "Du skrev riktig brukernavn og passord!";
	} else {
		// Hvis brukernavn og/eller passord er feil, fortell det til brukeren.
		pStatus.innerText = "Du skrev feil brukernavn og passord!";
	}
	
});