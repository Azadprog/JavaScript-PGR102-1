// Først lager vi en referanse til DOM-elementet <input id="inputUserColor" />
var inputUserColorElement = document.getElementById("inputUserColor");

// Så lager vi en referanse til DOM-elementet <button id="btnSetBackgroundColor">
var btnSetBackgroundColorElement = document.getElementById("btnSetBackgroundColor");

// Så setter vi en event-lytter på knappen -- med andre ord ønsker vi å lytte på om brukeren trykker på knappen referert til på forrige kodelinje.
btnSetBackgroundColorElement.addEventListener('click', function() {
	
	// Så bruker vi document.body som en referanse til DOM-elementet <body>, og setter bakgrunnsfargen til å være lik det brukeren skrev inn i <input>-elementet.
	document.body.style.backgroundColor = inputUserColorElement.value;
});